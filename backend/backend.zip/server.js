'use strict';
require('dotenv').config();
const express = require('express');
const user = require('./models/user');
const video = require('./models/video');
const logger = require('./logger/logger');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const sequelize = require("sequelize");
const {
	CronJob
} = require('cron');
const {
	addLinkToDatabase,
	getLastVideoLink,
	getAllLinksFromDatabase,
	updateLinkInDatabase,
	deleteLinkFromDatabase,
	getByIDFromDatabase
} = require('./models/video');
const randomVideo = require('./services/randomVideoService');
const app = express();

const sql = new sequelize(
	process.env.DB_NAME,
	"root",
	'12345', {
		host: 'localhost',
		dialect: "mysql",
		// port: process.env.PORT || 3306
	}
);

sql.authenticate().then(() => {
		console.log('Connection has been established successfully.');
	}).catch((error) => {
		console.error('Unable to connect to the database: ', error);
	})
	.then(() => {
		user.sync();
	}).then(() => {
		video.sync();
	}).then(
		// require('./seed/seeder'), // Seed the database, ONLY ONCE MUST RUN
		// logger.info('Data has been seeded into the database.'),
	).catch(err => logger.error(err));


//Cross Origin Resource Sharing
app.use(cors());
// app.use(morgan('combined', {
// 	stream: logger.stream
// }));
app.use(bodyParser.urlencoded({
	extended: false
}));
app.use(express.static('public'));
app.use(bodyParser.json());


// // create admin user
// (async () => {
// 	const username = 'admin';
// 	const email = 'tarara@tarara.hu';
// 	const password = 'tarara';
// 	const hashedPassword = await bcrypt.hash(password, 10);
// 	const user = await User.findOne({
// 		where: {
// 			username
// 		}
// 	});
// 	if (!user) {
// 		await user.create({
// 			username,
// 			password: hashedPassword,
// 			email
// 		});
// 		console.log(`Admin user has been added with username: ${username}, email: ${email}`);
// 	}
// })();

// Schedule cron job to update video every 24 hours
const task = new CronJob('0 1 0 * * *', async () => {
	let tries = 0;
	let video = null;
	while (!video && tries < 3) {
		try {
			video = await randomVideo.getRandomVideo();
		} catch (error) {
			console.error(error);
			tries++;
		}
	}

	if (video) {
		try {
			const result = await addLinkToDatabase(video);
			console.log(`New video link has been added to the database: ${result.link}`);
		} catch (error) {
			console.error(error);
		}
	}

}, null, true, 'Europe/Budapest');
task.start();

// Authentication middleware
const authenticateJwt = async (req, res, next) => {
	const authHeader = req.headers['authorization'];
	const token = authHeader && authHeader.split(' ')[1];
	if (token == null) {
		return res.sendStatus(401);
	}

	try {
		const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
		req.user = decoded;
		next();
	} catch (error) {
		console.error(error);
		res.sendStatus(403);
	}
};

// Routes
app.post('/login', async (req, res) => {
	try {
		const {
			username,
			password
		} = req.body;

		const user = await Users.findOne({
			where: {
				username
			}
		});

		if (!user) {
			return res.status(404).json({
				error: 'This user does not exist'
			});
		}

		const valid = await bcrypt.compare(password, user.password);
		if (valid) {
			const accessToken = jwt.sign({
					username: user.username
				},
				'bociBociTarkaSeFuleSeFarka', {
					expiresIn: '1h'
				}
			);

			return res.json({
				accessToken,
				user: {
					...user.toJSON(),
					password: ''
				},
			});
		} else {
			return res.status(401).send('Incorrect username or password');
		}
	} catch (error) {
		console.error(error);
		return res.status(500).send('Error logging in');
	}
});

app.get('/', async (req, res) => {
	try {
		const row = await getLastVideoLink();
		res.send(row);
	} catch (error) {
		console.error(error);
		res.status(500).send('Error retrieving video link');
	}
});

app.get('/all', authenticateJwt, async (req, res) => {
	try {
		const rows = await getAllLinksFromDatabase();
		res.send(rows);
	} catch (error) {
		console.error(error);
		res.status(500).send('Error retrieving video links');
	}
});

app.post('/create', authenticateJwt, async (req, res) => {
	try {
		const {
			id,
			link,
			created_at
		} = req.body;
		const record = await addLinkToDatabase(link, created_at);
		res.status(201).json({
			message: 'Video link added successfully',
			record
		});
	} catch (error) {
		console.error(error);
		res.status(500).send('Error adding video link');
	}
});


app.put('/:id', authenticateJwt, async (req, res, next) => {
	const {
		id
	} = req.params;
	const {
		link,
		created_at
	} = req.body;

	if (!link || !created_at || !id) {
		return res.status(400).json({
			error: 'Missing fields'
		});
	}

	const isValidDate = (dateString) => {
		return !isNaN(Date.parse(dateString));
	};

	if (!isValidDate(created_at)) {
		return res.status(400).json({
			error: 'Invalid date format'
		});
	}

	try {
		const video = await updateLinkInDatabase(id, {
			link,
			created_at
		});
		res.status(200).json({
			message: 'Video successfully updated'
		});
	} catch (error) {
		next(error);
	}
});

app.get('/:id', authenticateJwt, async (req, res, next) => {
	const id = req.params.id;
	try {
		const video = await getByIDFromDatabase(id);
		if (video) {
			res.json(video);
		} else {
			res.status(404).json({
				error: 'Video not found'
			});
		}
	} catch (error) {
		next(error);
	}
});

// DELETE
app.delete('/:id', authenticateJwt, async (req, res) => {
	try {
		const id = req.params.id;
		const result = await deleteLinkFromDatabase(id);
		if (result === 0) {
			res.status(200).json({
				message: 'The video link has been deleted.'
			});
		} else {
			res.status(404).json({
				message: 'Video link not found.'
			});
		}
	} catch (error) {
		console.error(error);
		res.status(500).json({
			error: 'Error deleting video link'
		});
	}
});

// CREATE
app.post('/user', authenticateJwt, async (req, res) => {
	try {
		const user = await User.create(req.body);
		res.status(201).json({
			message: 'New user has been created.'
		});
	} catch (error) {
		console.error(error);
		res.status(500).json({
			error: 'Error creating user.'
		});
	}
});

// READ ALL
app.get('/user/all', authenticateJwt, async (req, res) => {
	try {
		const users = await User.findAll();
		res.json(users);
	} catch (error) {
		console.error(error);
		res.status(500).send('Error fetching users');
	}
});

// READ ONE
app.get('/user/:id', authenticateJwt, async (req, res) => {
	try {
		const user = await User.findByPk(req.params.id);
		if (!user) {
			res.status(404).send('User not found');
		} else {
			res.json(user);
		}
	} catch (error) {
		console.error(error);
		res.status(500).send('Error fetching user');
	}
});

// UPDATE
app.put('/user/:id', authenticateJwt, async (req, res) => {
	try {
		let updatedUser = req.body;
		if (updatedUser.password) {
			const salt = await bcrypt.genSalt(10);
			const hashedPassword = await bcrypt.hash(updatedUser.password, salt);
			updatedUser.password = hashedPassword;
		}
		const result = await User.update(updatedUser, {
			where: {
				id: req.params.id
			}
		});
		if (result[0] === 0) {
			res.status(404).send('User not found');
		} else {
			res.status(200).json({
				message: 'The user has been updated.'
			});
		}
	} catch (error) {
		console.error(error);
		res.status(500).send('Error updating user');
	}
});

// DELETE
app.delete('/user/:id', authenticateJwt, async (req, res) => {
	try {
		const result = await User.destroy({
			where: {
				id: req.params.id
			}
		});
		res.status(200).json({
			message: 'The user has been deleted.'
		});
	} catch (error) {
		console.error(error);
		res.status(500).json({
			error: 'Error deleting user'
		});
	}
});

module.exports = app;