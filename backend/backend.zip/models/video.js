const {
	Sequelize,
	DataTypes
} = require('sequelize');
const randomVideo = require('../services/randomVideoService');

const sequelize = new Sequelize(process.env.dbPath || 'mysql://user:password@localhost:3306/videos', {
	dialect: 'mysql'
});

const Video = sequelize.define('Video', {
	id: {
		type: DataTypes.INTEGER,
		allowNull: false,
		primaryKey: true,
		autoIncrement: true
	},
	link: {
		type: DataTypes.STRING,
		allowNull: false
	},
	created_at: {
		type: DataTypes.DATE,
		allowNull: false,
		defaultValue: Sequelize.NOW
	}
}, {
	timestamps: false
});

const addLinkToDatabase = async (link, created_at) => {
	try {
		if (!link) {
			throw new Error('Link is missing');
		}
		const video = await Video.create({
			link: link,
			created_at: created_at || new Date().toISOString()
		});
		return {
			id: video.id,
			link: video.link,
			created_at: video.created_at
		};
	} catch (err) {
		throw err;
	}
};

const getAllLinksFromDatabase = async () => {
	try {
		const videos = await Video.findAll({
			attributes: ['id', 'link', 'created_at']
		});
		return videos.map(video => ({
			id: video.id,
			link: video.link,
			created_at: video.created_at
		}));
	} catch (err) {
		throw err;
	}
};

const getByIDFromDatabase = async (id) => {
	try {
		const video = await Video.findOne({
			where: {
				id: id
			},
			attributes: ['id', 'link', 'created_at']
		});
		return video ? {
			id: video.id,
			link: video.link,
			created_at: video.created_at
		} : null;
	} catch (err) {
		throw err;
	}
};

const getLastVideoLink = async () => {
	try {
		const video = await Video.findOne({
			order: [
				['id', 'DESC']
			],
			attributes: ['id', 'link', 'created_at']
		});
		if (video && video.link) {
			return {
				id: video.id,
				link: video.link,
				created_at: video.created_at
			};
		} else {
			const link = await randomVideo.getRandomVideo();
			const newVideo = await Video.create({
				link: link,
				created_at: new Date().toISOString()
			});
			return {
				id: newVideo.id,
				link: newVideo.link,
				created_at: newVideo.created_at
			};
		}
	} catch (err) {
		throw new Error(err.message);
	}
};

const updateLinkInDatabase = async (id, {
	link,
	created_at
}) => {
	const formattedDate = new Date(created_at).toISOString().replace('T', ' ').slice(0, -5);
	try {
		const result = await Video.update({
			link: link,
			created_at: formattedDate
		}, {
			where: {
				id: id
			}
		});
		if (result[0] === 0) {
			throw new Error("Video not found");
		}
		const video = await Video.findOne({
			where: {
				id: id
			},
			attributes: ['id', 'link', 'created_at']
		});
		return {
			id: video.id,
			link: video.link,
			created_at: video.created_at
		};
	} catch (err) {
		throw err;
	}
};

const deleteLinkFromDatabase = async (id) => {
	try {
		const result = await Video.destroy({
			where: {
				id: id
			}
		});
		return result ? 1 : 0;
	} catch (error) {
		throw new Error(error.message);
	}
}


module.exports = {
	addLinkToDatabase,
	getAllLinksFromDatabase,
	getLastVideoLink,
	updateLinkInDatabase,
	deleteLinkFromDatabase,
	getByIDFromDatabase
};